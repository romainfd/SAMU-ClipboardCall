# ClipboardCall

Let's you call a phone number from your clipboard simply by clicking a button on the Bandeau Si-SAMU.

## Building
```
web-ext build -i sign.sh
```
